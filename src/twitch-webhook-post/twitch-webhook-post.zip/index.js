const crypto = require('crypto')

exports.handler = async event => {
  const verify = () => {
    const expected = event.headers['x-hub-signature'];
    const calculated = 'sha256=' + crypto.createHmac('sha256', process.env.webhook_secret).update(JSON.stringify(event.body)).digest('hex');
    console.log(expected, calculated);
    return expected === calculated;
  };

  // If verification fails we log the failure and return a response to the request
  if(!verify) {
    console.warn('Verification failed', event);
    return { statusCode: 200 };
  }

  return { statusCode: 200 };
};